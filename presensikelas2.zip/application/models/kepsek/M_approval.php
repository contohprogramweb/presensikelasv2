<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_approval extends CI_Model {

    public function __construct()
    {
        parent::__construct();
    }

    public function get_pending_approval()
    {
        $this->db->select('a.*, p.tanggal, p.status as status_presensi, p.keterangan, p.materi_pelajaran');
        $this->db->select('s.nama as nama_siswa, k.nama_kelas');
        $this->db->select('g.nama as nama_guru, u.nama_lengkap as user_nama');
        $this->db->from('tb_approval a');
        $this->db->join('tb_presensi p', 'p.id = a.id_presensi');
        $this->db->join('tb_siswa s', 's.id = p.id_siswa');
        $this->db->join('tb_user u', 'u.id = s.id_user');
        $this->db->join('tb_kelas k', 'k.id = s.id_kelas', 'left');
        $this->db->join('tb_jadwal j', 'j.id = p.id_jadwal');
        $this->db->join('tb_guru g', 'g.id = j.id_guru');
        $this->db->where('a.status_approval', 'pending');
        $this->db->order_by('p.tanggal', 'DESC');
        
        return $this->db->get()->result_array();
    }

    public function approve($id_approval, $id_approver)
    {
        $data = [
            'status_approval' => 'disetujui',
            'tanggal_approval' => date('Y-m-d H:i:s'),
            'id_approver' => $id_approver
        ];
        
        $this->db->where('id', $id_approval);
        return $this->db->update('tb_approval', $data);
    }

    public function reject($id_approval, $id_approver, $catatan)
    {
        $this->db->trans_start();
        
        // Update approval status
        $data_approval = [
            'status_approval' => 'ditolak',
            'tanggal_approval' => date('Y-m-d H:i:s'),
            'id_approver' => $id_approver,
            'catatan' => $catatan
        ];
        
        $this->db->where('id', $id_approval);
        $this->db->update('tb_approval', $data_approval);
        
        // Get presensi ID
        $this->db->where('id', $id_approval);
        $approval = $this->db->get('tb_approval')->row_array();
        
        if ($approval) {
            // Update presensi status to Alpa
            $this->db->where('id', $approval['id_presensi']);
            $this->db->update('tb_presensi', ['status' => 'Alpa']);
        }
        
        $this->db->trans_complete();
        
        return $this->db->trans_status();
    }

    public function get_by_id($id)
    {
        $this->db->select('a.*, p.tanggal, p.status as status_presensi, p.keterangan, p.materi_pelajaran');
        $this->db->select('s.nama as nama_siswa, k.nama_kelas');
        $this->db->select('g.nama as nama_guru, u.nama_lengkap as user_nama');
        $this->db->from('tb_approval a');
        $this->db->join('tb_presensi p', 'p.id = a.id_presensi');
        $this->db->join('tb_siswa s', 's.id = p.id_siswa');
        $this->db->join('tb_user u', 'u.id = s.id_user');
        $this->db->join('tb_kelas k', 'k.id = s.id_kelas', 'left');
        $this->db->join('tb_jadwal j', 'j.id = p.id_jadwal');
        $this->db->join('tb_guru g', 'g.id = j.id_guru');
        $this->db->where('a.id', $id);
        
        return $this->db->get()->row_array();
    }
}
