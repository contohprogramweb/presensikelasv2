<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_siswa extends CI_Model {

    private $table = 'tb_siswa';

    public function __construct()
    {
        parent::__construct();
    }

    public function get_all_datatables($id_tahun_ajaran = null)
    {
        $this->db->select('s.*, k.nama_kelas, u.username, u.status as user_status');
        $this->db->from($this->table . ' s');
        $this->db->join('tb_kelas k', 'k.id = s.id_kelas', 'left');
        $this->db->join('tb_user u', 'u.id = s.id_user');
        
        if ($id_tahun_ajaran) {
            $this->db->where('k.id_tahun_ajaran', $id_tahun_ajaran);
        }
        
        return $this->db->get()->result_array();
    }

    public function get_by_id($id)
    {
        return $this->db->get_where($this->table, ['id' => $id])->row_array();
    }

    public function insert($data)
    {
        return $this->db->insert($this->table, $data);
    }

    public function update($id, $data)
    {
        $this->db->where('id', $id);
        return $this->db->update($this->table, $data);
    }

    public function delete($id)
    {
        $this->db->where('id', $id);
        return $this->db->delete($this->table);
    }

    public function get_kelas_for_select($id_tahun_ajaran = null)
    {
        $this->db->select('id, nama_kelas');
        $this->db->from('tb_kelas');
        if ($id_tahun_ajaran) {
            $this->db->where('id_tahun_ajaran', $id_tahun_ajaran);
        }
        return $this->db->get()->result_array();
    }

    public function check_nis_exists($nis, $exclude_id = null)
    {
        $this->db->where('nis', $nis);
        if ($exclude_id) {
            $this->db->where('id !=', $exclude_id);
        }
        return $this->db->get($this->table)->num_rows() > 0;
    }
}
