<?php
$mode              = $mode ?? 'tambah';
$is_edit           = ($mode === 'edit');
$presensi_existing = $presensi_existing ?? null;
$siswa_presensi_map = $siswa_presensi_map ?? [];
$form_action       = $is_edit
    ? site_url('guru/presensi/update')
    : site_url('guru/presensi/simpan');
$materi_default    = $is_edit ? html_escape($presensi_existing['materi_pelajaran'] ?? '') : '';
?>
<div class="content-wrapper">
<div class="container-fluid">
    <div class="page-heading d-flex align-items-center justify-content-between">
        <h2>
            <i class="fas fa-clipboard-check me-2"></i>
            <?= $page_title ?? ($is_edit ? 'Edit Presensi' : 'Input Presensi'); ?>
        </h2>
        <?php if ($is_edit): ?>
            <span class="badge bg-warning text-dark fs-6"><i class="fas fa-pencil-alt me-1"></i>Mode Edit</span>
        <?php endif; ?>
    </div>
    
    <?php if ($this->session->flashdata('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-circle me-2"></i><?= $this->session->flashdata('error'); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <?php if ($this->session->flashdata('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i><?= $this->session->flashdata('success'); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <?php if ($this->session->flashdata('info')): ?>
        <div class="alert alert-info alert-dismissible fade show" role="alert">
            <i class="fas fa-info-circle me-2"></i><?= $this->session->flashdata('info'); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header">
            <h5 class="mb-0"><i class="fas fa-info-circle me-2"></i>Informasi Jadwal</h5>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <table class="table table-borderless table-sm">
                        <tr>
                            <td width="150"><strong>Mata Pelajaran</strong></td>
                            <td>: <?= html_escape($jadwal['nama_mapel'] ?? '-'); ?></td>
                        </tr>
                        <tr>
                            <td><strong>Kelas</strong></td>
                            <td>: <?= html_escape($jadwal['nama_kelas'] ?? '-'); ?></td>
                        </tr>
                        <tr>
                            <td><strong>Hari</strong></td>
                            <td>: <?= html_escape($jadwal['hari'] ?? '-'); ?></td>
                        </tr>
                    </table>
                </div>
                <div class="col-md-6">
                    <table class="table table-borderless table-sm">
                        <tr>
                            <td width="150"><strong>Jam</strong></td>
                            <td>: <?= date('H:i', strtotime($jadwal['jam_mulai'] ?? '00:00')) ?> - <?= date('H:i', strtotime($jadwal['jam_selesai'] ?? '00:00')) ?></td>
                        </tr>
                        <tr>
                            <td><strong>Ruangan</strong></td>
                            <td>: <?= html_escape($jadwal['ruangan'] ?? '-'); ?></td>
                        </tr>
                        <tr>
                            <td><strong>Tanggal</strong></td>
                            <td>: <?= tanggal_indo($tanggal ?? date('Y-m-d')); ?></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <form action="<?= $form_action; ?>" method="post" id="formPresensi">
        <?php if ($is_edit): ?>
            <?= form_hidden('id_presensi', $presensi_existing['id'] ?? ''); ?>
        <?php else: ?>
            <?= form_hidden('id_jadwal', $jadwal['id'] ?? ''); ?>
            <?= form_hidden('tanggal', $tanggal ?? date('Y-m-d')); ?>
        <?php endif; ?>
        
        <div class="card mt-3">
            <div class="card-header">
                <h5 class="mb-0"><i class="fas fa-book me-2"></i>Materi Pelajaran</h5>
            </div>
            <div class="card-body">
                <div class="mb-3">
                    <textarea name="materi_pelajaran" class="form-control" rows="3"
                        placeholder="Tulis materi pelajaran yang diajarkan hari ini..."
                        required><?= $materi_default ?: set_value('materi_pelajaran'); ?></textarea>
                    <small class="text-muted">Materi pelajaran wajib diisi sebelum menyimpan presensi.</small>
                </div>
            </div>
        </div>

        <div class="card mt-3">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0"><i class="fas fa-users me-2"></i>Daftar Siswa</h5>
                <small class="text-muted"><?= count($siswa_list); ?> siswa</small>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover">
                        <thead class="table-light">
                            <tr>
                                <th width="5%">No</th>
                                <th width="35%">Nama Siswa</th>
                                <th width="45%" colspan="4">Status Kehadiran</th>
                                <th width="15%">Keterangan</th>
                            </tr>
                            <tr>
                                <th></th>
                                <th></th>
                                <th width="10%"><label class="radio-inline"><input type="radio" name="status_all" value="Hadir" class="status-all"> Hadir</label></th>
                                <th width="10%"><label class="radio-inline"><input type="radio" name="status_all" value="Izin" class="status-all"> Izin</label></th>
                                <th width="10%"><label class="radio-inline"><input type="radio" name="status_all" value="Sakit" class="status-all"> Sakit</label></th>
                                <th width="10%"><label class="radio-inline"><input type="radio" name="status_all" value="Alpa" class="status-all"> Alpa</label></th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($siswa_list)): ?>
                                <tr>
                                    <td colspan="7" class="text-center text-muted">Tidak ada siswa di kelas ini</td>
                                </tr>
                            <?php else: ?>
                                <?php $no = 1; foreach ($siswa_list as $siswa):
                                    // Untuk mode edit: ambil status & keterangan dari data existing
                                    $existing_status     = $siswa_presensi_map[$siswa['id']]['status']     ?? 'Hadir';
                                    $existing_keterangan = $siswa_presensi_map[$siswa['id']]['keterangan'] ?? '';
                                ?>
                                    <tr>
                                        <td><?= $no++; ?></td>
                                        <td>
                                            <strong><?= html_escape($siswa['nama_lengkap']); ?></strong>
                                        </td>
                                        <td>
                                            <label class="radio-inline">
                                                <input type="radio" name="siswa[<?= $siswa['id']; ?>][status]" value="Hadir"
                                                    <?= ($existing_status === 'Hadir') ? 'checked' : ''; ?>> H
                                            </label>
                                        </td>
                                        <td>
                                            <label class="radio-inline">
                                                <input type="radio" name="siswa[<?= $siswa['id']; ?>][status]" value="Izin"
                                                    <?= ($existing_status === 'Izin') ? 'checked' : ''; ?>> I
                                            </label>
                                        </td>
                                        <td>
                                            <label class="radio-inline">
                                                <input type="radio" name="siswa[<?= $siswa['id']; ?>][status]" value="Sakit"
                                                    <?= ($existing_status === 'Sakit') ? 'checked' : ''; ?>> S
                                            </label>
                                        </td>
                                        <td>
                                            <label class="radio-inline">
                                                <input type="radio" name="siswa[<?= $siswa['id']; ?>][status]" value="Alpa"
                                                    <?= ($existing_status === 'Alpa') ? 'checked' : ''; ?>> A
                                            </label>
                                        </td>
                                        <td>
                                            <input type="text"
                                                name="siswa[<?= $siswa['id']; ?>][keterangan]"
                                                class="form-control form-control-sm keterangan-siswa"
                                                placeholder="Keterangan..."
                                                value="<?= html_escape($existing_keterangan); ?>">
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="card mt-3">
            <div class="card-body text-end">
                <a href="<?= site_url('guru/presensi'); ?>" class="btn btn-secondary">
                    <i class="fas fa-arrow-left me-1"></i>Batal
                </a>
                <button type="submit" class="btn <?= $is_edit ? 'btn-warning' : 'btn-primary'; ?>" id="btnSimpanPresensi">
                    <i class="fas fa-save me-1"></i><?= $is_edit ? 'Simpan Perubahan' : 'Simpan Presensi'; ?>
                </button>
            </div>
        </div>
    </form>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
$(document).ready(function() {
    var isSubmitting = false;
    var isEdit = <?= $is_edit ? 'true' : 'false'; ?>;
    
    // Handle radio button "select all" untuk status
    $('input[name="status_all"]').on('change', function() {
        var selectedStatus = $(this).val();
        $('input[name^="siswa"][name$="[status]"][value="' + selectedStatus + '"]').prop('checked', true);
    });

    // Handle form submit dengan konfirmasi JS
    $('#formPresensi').on('submit', function(e) {
        e.preventDefault();
        
        if (isSubmitting) return false;
        
        // Validasi materi pelajaran
        var materiPelajaran = $('textarea[name="materi_pelajaran"]').val().trim();
        if (materiPelajaran === '') {
            Swal.fire({
                icon: 'warning',
                title: 'Peringatan',
                text: 'Materi pelajaran wajib diisi!',
                confirmButtonText: 'OK',
                confirmButtonColor: '#f39c12'
            });
            return false;
        }
        
        // Hitung jumlah siswa per status
        var totalSiswa = <?= count($siswa_list); ?>;
        var hadirCount = 0, sakitCount = 0, izinCount = 0, alphaCount = 0;
        
        $('input[name^="siswa"][name$="[status]"]:checked').each(function() {
            var status = $(this).val();
            if (status === 'Hadir') hadirCount++;
            else if (status === 'Sakit') sakitCount++;
            else if (status === 'Izin') izinCount++;
            else if (status === 'Alpa') alphaCount++;
        });
        
        var summaryHtml = '<div style="text-align: left; padding: 10px;">' +
            '<div style="background-color: #f8f9fa; padding: 15px; border-radius: 8px; margin-bottom: 15px;">' +
                '<h6 style="margin-bottom: 10px; color: #495057;"><i class="fas fa-users"></i> Ringkasan Kehadiran</h6>' +
                '<table style="width: 100%;">' +
                    '<tr><td style="padding:5px 0;"><span style="color:#28a745;"><i class="fas fa-check-circle"></i> <strong>Hadir:</strong></span></td><td style="padding:5px 0;text-align:right;"><strong>' + hadirCount + '</strong> siswa</td></tr>' +
                    '<tr><td style="padding:5px 0;"><span style="color:#17a2b8;"><i class="fas fa-bed"></i> <strong>Sakit:</strong></span></td><td style="padding:5px 0;text-align:right;"><strong>' + sakitCount + '</strong> siswa</td></tr>' +
                    '<tr><td style="padding:5px 0;"><span style="color:#fd7e14;"><i class="fas fa-envelope"></i> <strong>Izin:</strong></span></td><td style="padding:5px 0;text-align:right;"><strong>' + izinCount + '</strong> siswa</td></tr>' +
                    '<tr><td style="padding:5px 0;"><span style="color:#dc3545;"><i class="fas fa-times-circle"></i> <strong>Alpa:</strong></span></td><td style="padding:5px 0;text-align:right;"><strong>' + alphaCount + '</strong> siswa</td></tr>' +
                    '<tr style="border-top:2px solid #dee2e6;"><td style="padding:10px 0 5px 0;"><strong>Total:</strong></td><td style="padding:10px 0 5px 0;text-align:right;"><strong>' + totalSiswa + '</strong> siswa</td></tr>' +
                '</table>' +
            '</div>' +
            '<p style="color:#6c757d;font-size:14px;"><i class="fas fa-info-circle"></i> Pastikan data sudah benar sebelum menyimpan.</p>' +
            '</div>';
        
        Swal.fire({
            title: isEdit
                ? '<i class="fas fa-pencil-alt"></i> Konfirmasi Edit Presensi'
                : '<i class="fas fa-clipboard-check"></i> Konfirmasi Presensi',
            html: summaryHtml,
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: isEdit ? '#ffc107' : '#28a745',
            cancelButtonColor: '#6c757d',
            confirmButtonText: isEdit
                ? '<i class="fas fa-save"></i> Ya, Simpan Perubahan!'
                : '<i class="fas fa-save"></i> Ya, Simpan!',
            cancelButtonText: '<i class="fas fa-times"></i> Batal',
            reverseButtons: true,
            focusConfirm: false
        }).then((result) => {
            if (result.isConfirmed) {
                isSubmitting = true;
                Swal.fire({
                    title: isEdit ? 'Memperbarui...' : 'Menyimpan...',
                    text: 'Data presensi sedang diproses.',
                    allowOutsideClick: false,
                    didOpen: () => { Swal.showLoading(); }
                });
                $('#formPresensi').off('submit');
                document.getElementById('formPresensi').submit();
            }
        });
        
        return false;
    });
});
</script>