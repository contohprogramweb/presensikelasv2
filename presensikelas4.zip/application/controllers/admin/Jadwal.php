<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Controller Jadwal Pelajaran - Admin
 * Mengelola jadwal pelajaran sekolah
 * 
 * @package     CodeIgniter
 * @subpackage  Controllers
 * @category    Admin
 */
class Jadwal extends MY_Controller {

    /**
     * Constructor
     */
    public function __construct() {
        parent::__construct();
        
        // Load model tahun ajaran jika belum dimuat
        if (!isset($this->M_tahunajaran)) {
            $this->load->model('admin/M_tahunajaran');
        }
        
        // Set role
        $this->role_required = array('admin');
        
        // Load model
        $this->load->model('admin/M_jadwal');
        $this->load->model('admin/M_kelas');
        $this->load->model('admin/M_matapelajaran');
        $this->load->model('admin/M_guru');
        
        // Set data global
        $this->data['page_title'] = 'Jadwal Pelajaran';
        $this->data['active_menu'] = 'jadwal';
    }

    /**
     * Halaman utama jadwal
     * 
     * @return void
     */
    public function index() {
        // Data tahun ajaran aktif sudah tersedia dari MY_Controller
        $this->data['tahun_ajaran'] = $this->tahun_ajaran_aktif;
        
        $this->data['content'] = 'admin/jadwal';
        $this->load->view('templates/template', $this->data);
    }

    /**
     * AJAX: Get list jadwal untuk DataTables
     * 
     * @return void
     */
    public function ajax_list() {
        $list = $this->M_jadwal->get_datatables($this->tahun_ajaran_aktif->id);
        $data = array();
        
        foreach ($list as $item) {
            $row = new stdClass();
            $row->DT_RowIndex = count($data);
            $row->nama_kelas = $item->nama_kelas;
            $row->hari = $item->hari;
            $row->jam_mulai = $item->jam_mulai;
            $row->jam_selesai = $item->jam_selesai;
            $row->nama_mapel = $item->nama_mapel;
            $row->nama_guru = $item->nama_guru;
            $row->tahun_ajaran = $item->tahun_ajaran;
            
            // Action buttons
            $row->action = '<div class="btn-group" role="group">';
            $row->action .= '<button type="button" class="btn btn-sm btn-info" onclick="edit_jadwal(\'' . encrypt_id($item->id) . '\')" title="Edit"><i class="fas fa-edit"></i></button>';
            $row->action .= ' <button type="button" class="btn btn-sm btn-danger" onclick="delete_jadwal(\'' . encrypt_id($item->id) . '\')" title="Hapus"><i class="fas fa-trash"></i></button>';
            $row->action .= '</div>';
            
            $data[] = $row;
        }
        
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->M_jadwal->count_all($this->tahun_ajaran_aktif->id),
            "recordsFiltered" => $this->M_jadwal->count_filtered($this->tahun_ajaran_aktif->id),
            "data" => $data,
        );
        
        $this->output->set_content_type('application/json')->set_output(json_encode($output));
    }

    /**
     * AJAX: Tambah jadwal baru
     * 
     * @return void
     */
    public function ajax_add() {
        // Debug log
        error_log("=== AJAX ADD JADWAL START ===");
        error_log("POST data: " . print_r($_POST, true));
        
        $data = array(
            'id_kelas' => $this->input->post('id_kelas'),
            'id_guru' => $this->input->post('id_guru'),
            'id_mapel' => $this->input->post('id_mapel'),
            'id_tahun_ajaran' => $this->tahun_ajaran_aktif->id,
            'hari' => $this->input->post('hari'),
            'jam_mulai' => $this->input->post('jam_mulai'),
            'jam_selesai' => $this->input->post('jam_selesai'),
            'ruangan' => $this->input->post('ruangan'),
            'status_aktif' => 1
        );
        
        error_log("Data to save: " . print_r($data, true));
        
        // Validate first
        $validation_result = $this->_validate();
        if ($validation_result !== TRUE) {
            error_log("Validation failed!");
            $this->output->set_status_header(400);
            $this->output->set_content_type('application/json')->set_output(json_encode($validation_result));
            return;
        }
        
        // Cek bentrok jadwal
        if ($this->M_jadwal->check_conflict($data)) {
            error_log("Jadwal bentrok!");
            $this->output->set_status_header(400);
            $this->output->set_content_type('application/json')->set_output(json_encode(array(
                'status' => FALSE,
                'message' => 'Jadwal bentrok dengan jadwal yang sudah ada pada kelas, hari, dan jam yang sama'
            )));
            return;
        }
        
        $insert = $this->M_jadwal->save($data);
        
        error_log("Insert result ID: " . $insert);
        log_aktivitas('insert', 'tb_jadwal', $insert, 'Tambah jadwal pelajaran');
        
        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'status' => TRUE,
            'message' => 'Jadwal berhasil ditambahkan'
        )));
    }

    /**
     * AJAX: Edit jadwal
     * 
     * @param string $encrypted_id ID terenkripsi
     * @return void
     */
    public function ajax_edit($encrypted_id) {
        $id = decrypt_id($encrypted_id);
        
        if (!$id) {
            $this->output->set_status_header(400);
            $this->output->set_content_type('application/json')->set_output(json_encode(array(
                'status' => FALSE,
                'message' => 'ID tidak valid'
            )));
            return;
        }
        
        $data = $this->M_jadwal->get_by_id($id);
        
        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'status' => TRUE,
            'data' => $data
        )));
    }

    /**
     * AJAX: Update jadwal
     * 
     * @return void
     */
    public function ajax_update() {
        $id = decrypt_id($this->input->post('id'));
        
        if (!$id) {
            $this->output->set_status_header(400);
            $this->output->set_content_type('application/json')->set_output(json_encode(array(
                'status' => FALSE,
                'message' => 'ID tidak valid'
            )));
            return;
        }
        
        $this->_validate();
        
        $data = array(
            'id_kelas' => $this->input->post('id_kelas'),
            'id_guru' => $this->input->post('id_guru'),
            'id_mapel' => $this->input->post('id_mapel'),
            'hari' => $this->input->post('hari'),
            'jam_mulai' => $this->input->post('jam_mulai'),
            'jam_selesai' => $this->input->post('jam_selesai'),
            'ruangan' => $this->input->post('ruangan'),
        );
        
        // Cek bentrok jadwal (kecuali jadwal ini sendiri)
        if ($this->M_jadwal->check_conflict($data, $id)) {
            $this->output->set_status_header(400);
            $this->output->set_content_type('application/json')->set_output(json_encode(array(
                'status' => FALSE,
                'message' => 'Jadwal bentrok dengan jadwal yang sudah ada pada kelas, hari, dan jam yang sama'
            )));
            return;
        }
        
        $this->M_jadwal->update($id, $data);
        
        log_aktivitas('update', 'tb_jadwal', $id, 'Update jadwal pelajaran');
        
        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'status' => TRUE,
            'message' => 'Jadwal berhasil diperbarui'
        )));
    }

    /**
     * AJAX: Hapus jadwal
     * 
     * @param string $encrypted_id ID terenkripsi
     * @return void
     */
    public function ajax_delete($encrypted_id) {
        $id = decrypt_id($encrypted_id);
        
        if (!$id) {
            $this->output->set_status_header(400);
            $this->output->set_content_type('application/json')->set_output(json_encode(array(
                'status' => FALSE,
                'message' => 'ID tidak valid'
            )));
            return;
        }
        
        $this->M_jadwal->delete($id);
        
        log_aktivitas('delete', 'tb_jadwal', $id, 'Hapus jadwal pelajaran');
        
        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'status' => TRUE,
            'message' => 'Jadwal berhasil dihapus'
        )));
    }

    /**
     * AJAX: Get dropdown data
     * 
     * @return void
     */
    public function ajax_get_dropdown() {
        $type = $this->input->get('type');
        
        // Debug log
        error_log("Dropdown type requested: " . $type);
        error_log("GET params: " . print_r($_GET, true));
        
        $data = array();
        
        if (empty($type)) {
            $this->output->set_content_type('application/json')->set_output(json_encode(['results' => []]));
            return;
        }
        
        switch ($type) {
            case 'kelas':
                $result = $this->M_kelas->get_active_classes();
                error_log("Kelas result count: " . (is_array($result) ? count($result) : 'not array'));
                if ($result && is_array($result) && count($result) > 0) {
                    foreach ($result as $item) {
                        $data[] = array('id' => $item->id, 'text' => $item->nama_kelas);
                    }
                }
                break;
            case 'guru':
                $result = $this->M_guru->get_active_teachers();
                error_log("Guru result count: " . (is_array($result) ? count($result) : 'not array'));
                if ($result && is_array($result) && count($result) > 0) {
                    foreach ($result as $item) {
                        $data[] = array('id' => $item->id, 'text' => $item->nama_guru);
                    }
                }
                break;
            case 'mapel':
                $result = $this->M_matapelajaran->get_active_subjects();
                error_log("Mapel result count: " . (is_array($result) ? count($result) : 'not array'));
                if ($result && is_array($result) && count($result) > 0) {
                    foreach ($result as $item) {
                        $data[] = array('id' => $item->id, 'text' => $item->nama_mapel);
                    }
                }
                break;
            default:
                error_log("Unknown dropdown type: " . $type);
                break;
        }
        
        error_log("Dropdown data count for {$type}: " . count($data));
        error_log("Dropdown data: " . json_encode($data));
        
        $this->output->set_content_type('application/json')->set_output(json_encode(['results' => $data]));
    }

    /**
     * Validasi input form
     * 
     * @return array|bool TRUE jika valid, array error jika tidak
     */
    private function _validate() {
        $data = array();
        $data['error'] = array();
        $data['status'] = TRUE;
        
        $this->form_validation->set_rules('id_kelas', 'Kelas', 'required');
        $this->form_validation->set_rules('id_guru', 'Guru', 'required');
        $this->form_validation->set_rules('id_mapel', 'Mata Pelajaran', 'required');
        $this->form_validation->set_rules('hari', 'Hari', 'required');
        $this->form_validation->set_rules('jam_mulai', 'Jam Mulai', 'required');
        $this->form_validation->set_rules('jam_selesai', 'Jam Selesai', 'required');
        
        if ($this->form_validation->run() === FALSE) {
            $fields = array('id_kelas', 'id_guru', 'id_mapel', 'hari', 'jam_mulai', 'jam_selesai');
            foreach ($fields as $field) {
                if (form_error($field)) {
                    $data['error'][$field] = form_error($field);
                }
            }
            $data['status'] = FALSE;
            return $data;
        }
        
        // Check jam selesai > jam mulai
        $jam_mulai = $this->input->post('jam_mulai');
        $jam_selesai = $this->input->post('jam_selesai');
        if ($jam_selesai <= $jam_mulai) {
            $data['error']['jam_selesai'] = 'Jam selesai harus lebih besar dari jam mulai';
            $data['status'] = FALSE;
            return $data;
        }
        
        return TRUE;
    }

     
}